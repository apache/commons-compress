## 1.2.10

- Fix registration process
- 
## 1.2.9

- Added the possibility to provide a validationCode for the signUp

## 1.2.8

- Fixed issues in Filters DSL

## 1.2.7

- Exported binary_utils
- Changed addKeyPair signature

## 1.2.6

- Registration API Use Client Process ID

## 1.2.5

- Fix jsonEncode error when calling registration api

## 1.2.4

- Changed forHcp to forDataOwner in filter_dsl

## 1.2.3

- Added simplified calls for registration

## 1.2.2

- Exported crypto from icure-dart-sdk

## 1.2.1

- Update dependencies

## 1.2.0

- Added getUserByEmail

## 1.1.5

- Update dependencies & add signup test

## 1.1.4

- Update dependencies

## 1.1.3

- Update dependencies

## 1.1.2

- Fix forPatient DataSample filter builder

## 1.1.1

- Update dependencies

## 1.1.0

- Added data samples API

## 1.0.7

- Better documentation, better top level api

## 1.0.6

- Performance improvement

## 1.0.5

- Fix transitive dependency problem

## 1.0.4

- Improve library layout

## 1.0.3

- Fix filter serialization, mapping and decryption of entities without encryption keys

## 1.0.2

- Fix filter mapping
- Add tests for healthcare professionals API

## 1.0.1

- Add healthcare elements API
- Add healthcare professionals API
- Improve test coverage
- Add constructors to filters

## 1.0.0

- Initial version


