# openapi.model.InlineResponse403

## Load the model package
```dart
import 'package:icure_medical_device_dart_sdk/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**short** | **int** |  | [optional] 
**char** | **String** |  | [optional] 
**int_** | **int** |  | [optional] 
**long** | **int** |  | [optional] 
**float** | **double** |  | [optional] 
**double_** | **double** |  | [optional] 
**direct** | **bool** |  | [optional] 
**readOnly** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


