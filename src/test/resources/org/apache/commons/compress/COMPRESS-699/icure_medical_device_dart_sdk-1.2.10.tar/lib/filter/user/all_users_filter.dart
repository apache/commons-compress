// @dart=2.12

part of icure_medical_device_dart_sdk.api;

class AllUsersFilter extends Filter<User> {
  AllUsersFilter({this.description});

  @override
  String? description;
}
