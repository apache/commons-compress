// @dart=2.12
part of icure_medical_device_dart_sdk.api;

abstract class Filter<O> {
  String? description;
}
