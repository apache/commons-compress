package foo;

import org.apache.commons.compress.compressors.pack200.Pack200CompressorInputStream;

import java.io.IOException;

public final class Foo {

	public static void main(final String... args) throws IOException {
		System.out.println("start");
		try (var inputStream = Foo.class.getClassLoader().getResourceAsStream("foo.pack")) {
			try (var compressInputStream = new Pack200CompressorInputStream(inputStream)) {
				compressInputStream.transferTo(System.out);
			}
		}
		System.out.println("end"); // never reached
	}
}