#!/bin/sh

# Must be run as root!

export YYYY=$1

echo $YYYY

date -s "$YYYY-01-01 00:00:00 -0000"
touch -h -a -d "$YYYY-01-01 00:00:03 -0000" $YYYY
touch -h -m -d "$YYYY-01-01 00:00:01 -0000" $YYYY

