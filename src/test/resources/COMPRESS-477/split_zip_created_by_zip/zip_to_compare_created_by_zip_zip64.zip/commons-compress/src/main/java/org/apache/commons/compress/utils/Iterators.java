/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

package org.apache.commons.compress.utils;

import java.util.Collection;
import java.util.Iterator;
import java.util.Objects;

/**
 * Iterator utilities.
 *
 * @since 1.13.
 */
public class Iterators {

    /**
     * Adds all the elements in the source {@code iterator} to the target
     * {@code collection}.
     *
     * <p>
     * When this method returns, the {@code iterator} will be "empty": its
     * {@code hasNext()} method returns {@code false}.
     * </p>
     *
     * @param <T> type of the elements contained inside the collection
     * @param collection target collection
     * @param iterator source
     * @return {@code true} if the target {@code collection} was modified as a
     *         result of this operation
     */
    public static <T> boolean addAll(final Collection<T> collection, final Iterator<? extends T> iterator) {
        Objects.requireNonNull(collection);
        Objects.requireNonNull(iterator);
        boolean wasModified = false;
        while (iterator.hasNext()) {
            wasModified |= collection.add(iterator.next());
        }
        return wasModified;
    }

    private Iterators() {
        // do not instantiate
    }

}
