package org.apache.commons.compress;

import org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry;
import org.apache.commons.compress.archivers.sevenz.SevenZFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test {
  public static void main(String[] args) throws IOException {
    byte[] buffer = new byte[4096];

    String dest = "/home/l00292966/code/commons_compress_liyiang/tempfile";

    SevenZFile sevenZFile = new SevenZFile(new File("/home/l00292966/code/commons_compress_liyiang/7z_archive_with_empty_file.7z"));
    SevenZArchiveEntry entry;

    while((entry = sevenZFile.getNextEntry()) != null) {
      if(entry.isDirectory()) {
        continue;
      }

      File curFile = new File(dest, entry.getName());
      File parent = curFile.getParentFile();
      if(!parent.exists()) {
        parent.mkdirs();
      }

      FileOutputStream fos = new FileOutputStream("curFile");
//      while(sevenZFile.read(buffer, 0, buffer.length)) {
//        fos.write(buffer);
//      }
    }

  }
}